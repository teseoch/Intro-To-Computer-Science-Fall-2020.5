package gui;

import core.GOL;
import processing.core.PApplet;

public class TestClass extends PApplet {
	private static final int CELL_SIZE = 10;
	private static final int EACH_FRAME = 10;
	private GOL game;
	private int frame;
	private boolean isPause;

	public static void main(String[] args) {
		PApplet.main("gui.TestClass");
	}

	public TestClass()
	{
		game = new GOL(50, 0.2);
		frame = 0;
		isPause = false;
	}

	public void keyPressed() {
		if(key == ' ')
			isPause = !isPause;
	}


	public void settings() {
		size(game.getSize()*CELL_SIZE, game.getSize()*CELL_SIZE);
	}

	public void draw(){
		//clear the window by drawing a large rect
		stroke(255, 255, 255);

		//set fill color to white
		fill(255, 255, 255);
		rect(0, 0, game.getSize()*CELL_SIZE, game.getSize()*CELL_SIZE);
		frame++;

		if (mousePressed) {
			//convert from px to grid
			int gridI = mouseX/CELL_SIZE;
			int gridJ = mouseY/CELL_SIZE;

			game.setAlive(gridI, gridJ);
		}

		//set fill color to green
		fill(0, 255, 0);
		for(int i = 0; i < game.getSize(); ++i)
		{
			for(int j = 0; j < game.getSize(); ++j)
			{
				if(game.isAlive(i, j)) {
					//x, y, w, h
					rect(i*CELL_SIZE, j*CELL_SIZE, CELL_SIZE, CELL_SIZE);
				}
			}
		}

		if(frame > EACH_FRAME)
		{
			if(!isPause)
				game.update();
			frame = 0;
		}
	} 
}