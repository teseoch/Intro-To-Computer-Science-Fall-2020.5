public class GeomObj extends Object {
	protected int x, y; //position
	protected String color;
	private static int counter;

	public GeomObj(String col, int x, int y)
	{
		color = col;
		this.x = x;
		this.y = y;

		counter++;
	}

	public GeomObj(String col)
	{
		this(col, 0, 0);
	}

	public GeomObj()
	{
		this("black");
	}


	public void setColor(String color)
	{
		this.color = color;
	}


	public double getArea()
	{
		return 0;
	}

	public void reset()
	{
		setColor("black");
		x = 0;
		y = 0;
	}

	@Override
	public String toString()
	{
		return "pos = (" + x + ", " + y + "), color = " + color;
	}



	public static int numberOfGO()
	{
		return counter;
	}

	public static double totalArea(GeomObj[] objects)
	{
		double area = 0;
		for(GeomObj go : objects)
			area += go.getArea();

		return area;
	}



	public static void main(String[] args) {
		GeomObj go = new GeomObj();
		go.setColor("black");
		go.getArea(); //return 0

		GeomObj.numberOfGO();
	}
}