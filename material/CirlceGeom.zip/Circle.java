public class Circle extends GeomObj {
	public double radius;
	private static int counter;

	public Circle(String color, double r, int x, int y)
	{
		//"new GeomObj(col, x, y)"
		super(color, x, y);
		radius = r;
		counter++;
	}

	public Circle(String color, double r)
	{
		//"new Circle(color, r, 0, 0)"
		this(color, r, 0, 0);
	}

	//overloading
	public Circle()
	{
		this("black", 0);
	}

	@Override
	public void reset()
	{
		super.reset();
		radius = 0;
	}

	@Override
	public double getArea()
	{
		return radius*radius*3.1415;
	}

	public double getRadius()
	{
		return radius;
	}


	public void setRadius(double r)
	{
		setColor("black");
		radius = r;
	}

	@Override
	public String toString()
	{
		return super.toString() + ", r = " + radius;
	}


	public static int numberOfC()
	{
		return counter;
	}




	public static void main(String[] args) {
		//no
		//Circle c = new GeomObj();
		//c.radius?

		//no
		//GeomObj o = new GeomObj();
		//Circle c = o;
		//c.radius

		//yes 1
		GeomObj o = new Circle();
		// o = new GeomObj();
		o.getArea(); //-> this will call the circle area

		//2
		GeomObj o = new Circle();
		o = new GeomObj();
		o.getArea(); //-> this will call the GeomObj area

		// o = new Rect();

		//(Circle)o, is o a cirlce?
		//if yes, then we can cover the type and be happy
		//if not, crash

		Circle co = (Circle)o;
		//no!
		o.radius

		//yes
		co.radius


		Circle circle = new Circle();
		circle.setRadius(10);
		circle.setColor("black");
		circle.getRadius();
		circle.getArea(); //100*3.1415

		GeomObj.numberOfGO();
		Circle.numberOfC();

		System.out.println(circle.toString());
		System.out.println(circle);

		// GeomObj go = new Circle();


		GeomObj[] objects = new GeomObj[4];
		objects[0] = new GeomObj("blue", 0, 0);
		objects[1] = new GeomObj("red", 10, 1);
		objects[2] = new Circle("orange", 5);
		objects[3] = new Circle("pink", 2);

		for(int i = 0; i < objects.length; ++i)
		{
			GeomObj go = objects[i];

			go.setColor("orange");

			System.out.println("i = " + i);
			System.out.println(go.getArea());
			System.out.println(go);
		}


	}
}